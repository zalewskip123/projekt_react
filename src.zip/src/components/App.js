import React, {useState, useEffect} from "react";

const JOKEAPI = "http://api.icndb.com/jokes/random";

const App = () => {
    const [joke, SetJoke] = useState('');

    const generatorJoke = () => {
        fetch(JOKEAPI)
            .then(res => res.json())
            .then(data => SetJoke(data.value.joke));
    }

    useEffect(() => {
        generatorJoke();
    }, [])

    return (
        <div>
            <p>{joke}</p>
            <button onClick={generatorJoke}>Nowy żart</button>
        </div>
    )
}

export default App;